package com.baomidou.mybatisplus.generator.config;

public interface IConfigBuilder<T> {

    T build();
}
